# مجموعة الحر القانونية — Master V1

مشروع Next.js جاهز للرفع إلى GitHub ثم النشر على Vercel.

## قاعدة البيانات
يوجد مخطط PostgreSQL/Prisma في `prisma/schema.prisma`. بعد إنشاء قاعدة PostgreSQL، ضع `DATABASE_URL` في متغيرات البيئة ثم نفّذ `npx prisma generate` و`npx prisma db push`.

## ملاحظة
الواجهة الحالية تعمل ببيانات تجريبية حتى يتم ربط قاعدة بياناتك الحقيقية. لا تضع كلمات المرور أو المفاتيح السرية داخل GitHub.